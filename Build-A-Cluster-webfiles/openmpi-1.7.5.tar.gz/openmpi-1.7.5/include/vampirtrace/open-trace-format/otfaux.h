#ifndef OTFAUX_H
#define OTFAUX_H

#include <otf.h>

/**
 *  @file otfauxlib/otfaux.h
 *
 */

#include <OTFAUX_State.h>
#include <OTFAUX_MsgMatching.h>
#include <OTFAUX_Thumbnail.h>

#endif /* OTFAUX_H */
